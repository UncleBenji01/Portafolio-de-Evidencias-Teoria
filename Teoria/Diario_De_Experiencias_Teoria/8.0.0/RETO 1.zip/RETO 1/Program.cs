﻿// Intregrantes: Rudy Molares, Bryan Quiñonez, Benjamin Aldana
Console.WriteLine("Reto 1");
for (int i = 0; i < 9; i++)
{
    if (i == 0 || i == 4)
    {
        for (int j = 0; j < 9; j++)
        {
            Console.Write('x');

        }

    }
    if ((i > 0 && i < 4) || i > 4)
    {
        Console.Write("x       x");
    }

    Console.WriteLine("");
}

// Letra O
Console.WriteLine(" ");
for (int m = 1; m <= 1; m++); 
{
    Console.WriteLine("x x x x x x x x x");
    Console.WriteLine("x               x");
    Console.WriteLine("x               x");
    Console.WriteLine("x               x");
    Console.WriteLine("x               x");
    Console.WriteLine("x               x");
    Console.WriteLine("x x x x x x x x x");
}
